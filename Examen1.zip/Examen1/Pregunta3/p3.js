function calcular() {
    var temp = document.getElementById("temp").value;
    var numero = document.querySelector('input[name="numero"]:checked').value;
    if (numero === "celsius") {
        var fahrenheit = (temp*9/5)+32;
        alert("La temperatura calculada es "+fahrenheit.toFixed(2)+"F");
    } 
    else {
        var celsius = (temp-5/9)/1.8;
        alert("La temperatura calculada es "+celsius.toFixed(2)+"C");
    }
}